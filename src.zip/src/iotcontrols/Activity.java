package iotcontrols;

import java.util.ArrayList;

import controller.page.PageController;
import javafx.animation.PathTransition;
import javafx.animation.PauseTransition;
import javafx.animation.Transition;
import javafx.scene.control.Label;
import javafx.scene.shape.ClosePath;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.Path;
import javafx.util.Duration;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PETER-PC
 */
public class Activity extends Label{
    public Activity(){}
    
    //build method for ensuring animations are ordered properly so as to not trigger error
    //construct animation from string
    public final static Transition getAnimation(Actor actor,String activityName) {
        Transition transition = null;
        switch(activityName){
            case "Lecturer1 Leave Toilet":
                Path p1 = AnimationSequence.getPath("pathToiletWaterCloset");
                Path p2 = AnimationSequence.getPath("pathToiletSink");
                if(actor.intersects(p1.getLayoutBounds()))
                    transition = new PathTransition(Duration.seconds(1), p1, actor);
                else
                    transition = new PathTransition(Duration.seconds(1), p2, actor);
                transition.setRate(-1);
                break;
            case "Lecturer1 go to Toilet From Corridor":
                Path p = AnimationSequence.getPath("pathCorridorToToilet");
                transition = new PathTransition(Duration.seconds(1), p, actor);
                break;
            case "Lecturer1 go to Toilet From Office1":
                break;
            case "Lecturer1 Observe lecture in LectureRoom1":
                break;
            case  "Lecturer1 end lecture":
                break;
            case  "Lecturer1 go to Office1":
                break;
            case "Lecturer1 Leave Office1":
                break;
            case  "Lecturer1 enter premise floorPlan":
                break;
            case "Lecturer1 leave premise floorPlan":
                break;
            case "Lecturer1 Toggle Tv switch in Office1":
                break;
            case "Lecturer1 Toggle AC in LectureRoom1":
                break;
            case "Lecturer1 Toggle Projector in LectureRoom1":
                break;
            case "Lecturer1 Toggle Wi-Fi":
                break;
            case "Lecturer1 Toggle Bulb":
                break;
            case "Lecturer1 Toggle PC":
                break;
            case "Lecturer1 Set Pc to Sleep":
                break;
            case "Lecturer1 Wake Pc":
                break;
            case "Lecturer1 Set Pc Usage to low":
                break;
            case "Lecturer1 Set Pc Usage to High":
                break;
            case "Lecturer1 Set Ac temperature low":
                break;
            case "Lecturer1 Set Ac temperature High":
                break;
            case "Lecturer1 Toggle Temperature Sensor in Office1":
                break;
            case "Lecturer1 Set Temperature Sensor for Low Temperature in LectureRoom1":
                break;
            case "Lecturer1 Set Temperature Sensor for Mid Temperature in LectureRoom1":
                break;
            case "Lecturer1 Set Temperature Sensor for High Temperature in LectureRoom1":
                break;
            case "Lecturer1 Toggle Temperature Sensor in LecturerRoom 1":
                break;
            case "Students1 attend lectures in LectureRoom1":
                break;
            case "Students1 Leave LectureRoom1":
                break;
            case "Lecturer2 Leave Toilet":
                break;
            case "Lecturer2 go to Toilet From Corridor":
                break;
            case "Lecturer2 go to Toilet From Office2":
                break;
            case "Lecturer2 Observe lecture in LectureRoom2":
                break;
            case "Lecturer2 end lecture":
                break;
            case "Lecturer2 go to Office2":
                break;
            case "Lecturer2 Leave Office2":
                break;
            case "Lecturer2 enter premise floorPlan":
                Path pEnterPremise = AnimationSequence.getPath("pathCorridor");
                LineTo start = (LineTo) pEnterPremise.getElements().get(0);
                Path path = new Path();
                path.getElements().addAll(new LineTo(start.getX(), start.getY()), new ClosePath());
                transition = new PathTransition(Duration.seconds(1), path, actor);
                break;
            case "Lecturer2 leave premise floorPlan":
                break;
            case "Lecturer2 Toggle Tv switch":
                break;
            case "Lecturer2 Toggle AC in LectureRoom1":
                break;
            case "Lecturer2 Toggle Projector":
                break;
            case "Lecturer2 Toggle Wi-Fi":
                break;
            case "Lecturer2 Toggle Bulb":
                break;
            case "Lecturer2 Toggle PC":
                break;
            case "Lecturer2 Set Pc to Sleep":
                break;
            case "Lecturer2 Wake Pc":
                break;
            case "Lecturer2 Set Pc Usage to low":
                break;
            case "Lecturer2 Set Pc Usage to High":
                break;
            case "Lecturer2 Set Ac temperature low":
                break;
            case "Lecturer2 Set Ac temperature High":
                break;
            case "Lecturer2 Toggle Temperature Sensor in Office2":
                break;
            case "Lecturer2 Set Temperature Sensor for Low Temperature in LectureRoom2":
                break;
            case "Lecturer2 Set Temperature Sensor for Mid Temperature in LectureRoom2":
                break;
            case "Lecturer2 Set Temperature Sensor for High Temperature in LectureRoom2":
                break;
            case "Lecturer2 Toggle Temperature Sensor in LecturerRoom2":
                break;
            case "Students2 attend lectures in LectureRoom2":
                break;
            case "Students2 Leave LectureRoom2":
                break;
            default:
                break;
        }
        
        return transition;
    }
    
    
    public void interactingAction(){
        
    }
        
}
