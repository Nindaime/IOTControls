package iotcontrols;

import java.util.ArrayList;
import javafx.geometry.Point2D;
import javafx.scene.control.Tooltip;
import javafx.scene.shape.Circle;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PETER-PC
 */
public class Actor extends Circle{
    public static ArrayList<Actor> actors = new ArrayList<>();
    private Point2D location;
    public enum ActorType{student,lecturer};
    public ActorType simType;
    private Room room;
    
    public Actor(String activityName, double x, double y){
        location = new Point2D(x,y);
        if(activityName.contains("Lecturer"))
            simType = ActorType.lecturer;
        else
            simType = ActorType.student;
        
        //debug
        for(Room r: Room.rooms){
            if(r.getRoom().contains(location))
                room = r;
        }
        setRadius(5);
        this.getStyleClass().add(simType.toString());

        actors.add(this);
    }
    
    public void enterRoom(){
        room.getRoom().getChildren().add(this);
        setLayoutX(location.getX());
        setLayoutY(location.getY());
    }
    
    public Room getRoom(){
        return room;
    }
    
    public static ArrayList<Actor> getActors(String name){
        ArrayList<Actor> aListActor = new ArrayList<>();
        for(Actor a: actors)
            if(name.contains(a.getId()))
                aListActor.add(a);
        //test
        return aListActor;
    }
    
    public void setLocation(double x, double y){
        location = new Point2D(x,y);
    }
    
    public Point2D getLocation(){
        return location;
    }
    
}
