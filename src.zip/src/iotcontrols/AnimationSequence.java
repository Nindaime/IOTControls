package iotcontrols;

import javafx.animation.*;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.event.ActionEvent;
import javafx.geometry.NodeOrientation;
import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Path;
import javafx.scene.shape.Rectangle;
import javafx.scene.transform.Transform;
import javafx.util.Duration;
import org.apache.batik.dom.svg.SAXSVGDocumentFactory;
import org.apache.batik.parser.PathParser;
import org.apache.batik.util.XMLResourceDescriptor;
import org.w3c.dom.Element;
import org.w3c.dom.svg.SVGDocument;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author PETER-PC
 */
public class AnimationSequence {
    private static SequentialTransition animationPlanner;

    public static SequentialTransition getAnimationPlanner(){
        return animationPlanner;
    }

    private static SVGDocument svgDrivePath;
//    private static double[][] animationRate = {
//            {1,.95,.85,.75,.65},
//            {1,1,.95,.95,.85,.85,.75,.75,.65,.65,.5},
//            {1,1,.95,.95,.85,.85,.75,.75,.65,.65,.5},
//            {.85,.85,.85,.75,.75,.75,.65,.65,.65,.5,.5},
//            {.5,.5,.5,.5,.5},
//            {1,1,1,1,1},
//            {.5, .5, -.5, .5, .5},
//            {.5, .5, .65, .65, .65, .75, .75, .75, .85, .85, .85},
//            {.5, .65, .65, .75, .75, .85, .85, .95, .95, 1, 1},
//            {-.5, -.65, -.65, -.75, -.75, -.85, -.85, -.95, -.95, -1, -1},
//            {1, .95, .85, .75, .65},
//            {1, 1, 1, 1, 1},
//            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
//            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
//            {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1},
//            {1, 1, 1, 1, 1}};
//    //    private Node car;
    private ArrayList<Node> VACS_Components;

    public AnimationSequence(){
//        this.car = car;
        PathParser parser = new PathParser();
        animationPlanner = new SequentialTransition();

        JavaFXPathElementHandler handler = new JavaFXPathElementHandler();
        parser.setPathHandler(handler);
        try {
            String xmlParser = XMLResourceDescriptor.getXMLParserClassName();
            SAXSVGDocumentFactory f = new SAXSVGDocumentFactory(xmlParser);

            File drivePath = new File("src/app-icons/NavigationMap.svg");
            svgDrivePath = f.createSVGDocument(drivePath.getAbsoluteFile().toURI().toString());
        }catch(IOException ex){}

    }

    public static Path getPath(String pathID){
        PathParser parser = new PathParser();
        JavaFXPathElementHandler handler = new JavaFXPathElementHandler();
        parser.setPathHandler(handler);
        String pathData, transform;

        Element selectedPath = svgDrivePath.getElementById(pathID);
        pathData = selectedPath.getAttributeNode("d").getValue();
        transform = selectedPath.getAttributeNode("transform").getValue();

        parser.parse(pathData);
        Path path = handler.getPath();

        String[] transforms = transform.split(",");
        path.getTransforms()
                .add(Transform.affine(Double.parseDouble(transforms[0]), Double.parseDouble(transforms[1]), Double.parseDouble(transforms[2]),
                        Double.parseDouble(transforms[3]), Double.parseDouble(transforms[4]), Double.parseDouble(transforms[5])));
        return path;
    }

//    public double getAnimRateFromPathID(String pathID){
//        int rowIndex = 0, columnIndex = 0; String output = ""; char c = '\u0000';
//        if(pathID.matches("entP_to[\\S]{2,3}")){
//            output = pathID.substring(7);
//            c = output.charAt(0);
//            columnIndex = Integer.parseInt(pathID.substring(8));
//            System.out.println("Column Index: "+columnIndex);
//            switch(c){
//                case 'B':
//                    rowIndex = 1;
//                    break;
//                case 'C':
//                    rowIndex = 2;
//                    break;
//                case 'D':
//                    rowIndex = 3;
//                    break;
//                case 'E':
//                    rowIndex = 4;
//                    break;
//            }
//            System.out.println("Row Index: "+rowIndex);
//
//            return animationRate[rowIndex][--columnIndex];
//        }else if(pathID.matches("entP_to[\\S]{2,}")){
//            rowIndex = 5;
//            switch(pathID){
//                case "entP_toFirstBarrier":
//                    columnIndex = 0;
//                    break;
//                case "entP_toSecondBarrier":
//                    columnIndex = 1;
//                    break;
//                case "entP_toEntExt":
//                    columnIndex = 2;
//                    break;
//                case "entP_toExtExt":
//                    columnIndex = 3;
//                    break;
//                case "extP_toExtExt":
//                    columnIndex = 4;
//                    break;
//            }
//
//            return animationRate[rowIndex][columnIndex];
//        }else if(pathID.matches("extP_toExtFrom[\\S]{9,}")){
//            output = pathID.substring(14);
//            c = output.charAt(0);
//            rowIndex = 6;
//            String columnIndexString = pathID.substring(15, 17);
//
//            if(columnIndexString.matches("[\\d][\\D]"))
//                columnIndexString = columnIndexString.charAt(0)+"";
//
//            columnIndex = Integer.parseInt(columnIndexString);
//            switch(c){
//                case 'B':
//                    rowIndex = 7;
//                    break;
//                case 'C':
//                    rowIndex = 8;
//                    break;
//                case 'D':
//                    rowIndex = 9;
//                    break;
//                case 'E':
//                    rowIndex = 10;
//                    break;
//            }
//
//            return animationRate[rowIndex][--columnIndex];
//        }else if(pathID.matches("extP_reverseFrom[\\S]{2,}")){
//            output = pathID.substring(16);
//            c = output.charAt(0);
//            rowIndex = 11;
//            System.out.println("extracted character @ index 16 is "+c);
//            columnIndex = Integer.parseInt(pathID.substring(17));
//            System.out.println("extracted character between index 15 and 17 is "+(pathID.length() == 18 ? pathID.substring(18) : pathID.substring(18)));
//            switch (c) {
//                case 'B':
//                    rowIndex = 12;
//                    break;
//                case 'C':
//                    rowIndex = 13;
//                    break;
//                case 'D':
//                    rowIndex = 14;
//                    break;
//                case 'E':
//                    rowIndex = 15;
//                    break;
//            }
//            System.out.println("Animation Rate for Row: "+rowIndex+" & Column: "+(columnIndex - 1));
//            return animationRate[rowIndex][columnIndex - 1];
//        }else
//            return 1;
//
//    }

//    public final void setAnimationSequence(Node actor, String... pathID) {
//        ArrayList<Animation> tempAnimationList = new ArrayList<>();
//        for(int i = 0; i < pathID.length; i++){
//            System.out.println("Get animation path for svg path id: "+pathID[i]);
//            Path p = getPath(pathID[i]);
////            if(pathID[i].matches("extP_toExtFrom[\\S]{9,}") || pathID[i].matches("extP_[\\w]{1,}C")){
//////                p.setTranslateX(-500);
//////                p.setTranslateY(-500);
////            }
//
////            p.setTranslateY(18);
//            PathTransition pT = new PathTransition(Duration.seconds(5), p, actor);
//            pT.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
//            pT.setInterpolator(Interpolator.EASE_BOTH);
////            pT.setRate(getAnimRateFromPathID(pathID[i]));
////            System.out.println("Animation Rate ["+i+"]: "+pT.getRate());
//
////            tempAnimationList.add(pT);
////
////            int barrierDuration = Integer.parseInt((c.getValue().toString()));
//////            int barrierDuration = 3;
////
////            int counter = 0;
////            counter = tempAnimationList.stream().filter((a) -> (a instanceof ParallelTransition)).map((_item) -> 1).reduce(counter, Integer::sum);
////            if (pathID[i].matches("entP_toFirstBarrier")){
////                tempAnimationList.add(getBarrierAnimation(VACS_Components.get(0), Duration.seconds(barrierDuration), -45));
////            }else if(pathID[i].matches("entP_toSecondBarrier")){
////                ParallelTransition plT = new ParallelTransition(getBarrierAnimation(VACS_Components.get(0), Duration.seconds(barrierDuration), 0), tempAnimationList.remove(2));
////                tempAnimationList.add(plT);
////                tempAnimationList.add(getBarrierAnimation(VACS_Components.get(1), Duration.seconds(barrierDuration), -45));
////            }else if(pathID[i].matches("entP_to[\\S]{2,3}") && (counter == 1)){
////                ParallelTransition plT = new ParallelTransition(getBarrierAnimation(VACS_Components.get(1), Duration.seconds(barrierDuration), 0), tempAnimationList.remove(4));
////                tempAnimationList.add(plT);
//////                tempAnimationList.add(getBarrierAnimation(VACS_Components.get(1), Duration.seconds(barrierDuration), 0));
////            }else if(pathID[i].matches("extP_toExtFrom[\\S]{9,}") && (counter == 2)){
////                tempAnimationList.add(sT.size() - 2, getBarrierAnimation(VACS_Components.get(3), Duration.seconds(barrierDuration), -45));
////                tempAnimationList.add(getBarrierAnimation(VACS_Components.get(3), Duration.seconds(barrierDuration), 0));
////            }
//        }
//
//        tempAnimationList.add(0, new PauseTransition(Duration.seconds(1)));
//
//        sT.addAll(tempAnimationList);
//        System.out.println("Animation contains: "+sT.size());
//    }

//    public ArrayList<Animation> getAnimationSequence() {
//        return sT;
//    }

    public SequentialTransition getAnimationSequence() {
        return animationPlanner;
    }

//    public void playAnimationSequence(){
//
//        for(Animation a: sT){
//            System.out.println("Animation "+a);
//            int currentIndex = sT.indexOf(a);
//
//            Animation nextAnimation = sT.get(++currentIndex);
//            a.setOnFinished(e -> nextAnimation.play());
//        }
//
//        sT.get(0).play();
//        System.out.println("Animation Started");
//    }

//    public void goToAnimationObject(AnimationSubject subject, Actor actor) {
//        PathTransition pT = new PathTransition(Duration.millis(800), getPath(subject.g), actor);
//        animationPlanner.getChildren().add(pT);
//    }

    //room here is floorPlan
    public void enterPremise(String name, int count, double x, double y){
        Room room = Room.stringToRoom(name);
        openDoor(room);

        for(int i=0; i < count; i++){
            if(name.contains("Lecturer1 enter premise")){
                Actor actor = new Actor(name, x, y);
                actor.setId("Lecturer1");
                Timeline tL = new Timeline(new KeyFrame(Duration.millis(400), (ActionEvent e) -> actor.enterRoom()));
                animationPlanner.getChildren().add(tL);
                System.out.println("Created Lecturer 1");
            }else if(name.contains("Lecturer2 enter premise")){
                Actor actor = new Actor(name, x, y);
                actor.setId("Lecturer2");
                Timeline tL = new Timeline(new KeyFrame(Duration.millis(400), (ActionEvent e) -> actor.enterRoom()));
                animationPlanner.getChildren().add(tL);
                System.out.println("Created Lecturer 2");
            }else{
                Actor actor = new Actor(name, x, y);
                actor.setId("Student"+(i+1));
                Timeline tL = new Timeline(new KeyFrame(Duration.millis(400), (ActionEvent e) -> actor.enterRoom()));
                animationPlanner.getChildren().add(tL);
                System.out.println("Created Student "+i);
            }

        }
        closeDoor(room);
//        return actor;
    }

    //assume actor is on corridor && room here is floorplan
    public void leavePremise(String name){
            Room room = Room.stringToRoom(name);
            Actor actor = Actor.getActors(name).get(0);

            if(!actor.getLocation().equals(room.getDoor().getContactPoint()))//might be redundant
                goToAnimationObject(room.getDoor(), actor);

            openDoor(room);
            room.getRoom().getChildren().remove(actor);

        //build sim objects for room
    }

    public void studentsAttendLecture(Room room){
        studentsToSit(room, true);
    }

    public void studentsLeaveLecture(Room room){
        studentsToSit(room, false);
    }

    public void toggleIoTDevices(Room room){
        for(Node p: room.getRoom().getChildren()){
            if(p instanceof Path && p.getId().matches(".+Light.+[.+View.+]"))//check regex
                toggleLight_View((Path)p, true);

        }

        for(SimObject i: room.getRoomObjects()){//loops through room objects to find IoT Devices
            if(i instanceof IoTDevice && ((IoTDevice)i).getObject() instanceof Path && i.getObject().getId().matches(".+Light.+[.+View.+]"))
                toggleLight_View( (Path)((IoTDevice)i).getObject(), ((IoTDevice)i).toggle());
        }
    }
//
//    //
    public void studentsToSit(Room room, boolean enterSit){
        ArrayList<Actor> students = new ArrayList<>();
        for(Node n: room.getRoom().getChildren()){
            if(n instanceof Actor && ((Actor)n).simType.equals(Actor.ActorType.student))
                students.add((Actor)n);
        }

        ArrayList<LectureRoomSit> sits = new ArrayList<>();
        for(SimObject l: room.getRoomObjects()){
            if(l instanceof LectureRoomSit)
                sits.add((LectureRoomSit)l);
        }

        for(int i=0; i < students.size(); i++){
            goToAnimationObject(sits.get(i), students.get(i));// go to the sit
            animationPlanner.getChildren().add(sits.get(i).setVacancy(students.get(i), enterSit)); //enter the sit
        }

    }
//
//
//    //actor is assumed infront of door
    public void leaveRoom(Room room, Actor actor){
        if(!actor.getLocation().equals(room.getDoor().getContactPoint()))
            goToAnimationObject(room.getDoor(), actor);

        //convert local coordinate to global coordinate
        Point2D newActorCoordinate = room.getRoom().localToParent(new Point2D(actor.getLayoutX(), actor.getLayoutY()));
        ((Pane)room.getRoom().getParent()).getChildren().add(actor);
        actor.setLayoutX(newActorCoordinate.getX());
        actor.setLayoutY(newActorCoordinate.getY());

        TranslateTransition tT = new TranslateTransition(Duration.millis(400), actor);
        tT.setByX(room.getContactPoint().getX() + 20);
        tT.setByY(room.getContactPoint().getY() + 20);
        tT.setDelay(Duration.millis(200));
        tT.setInterpolator(Interpolator.EASE_BOTH);
        animationPlanner.getChildren().add(tT);
    }

//    public void enterRoom(Room room, Actor actor){
//        animationPlanner.getChildren().add(enterRoomAnim(room, actor));
//    }

    public void enterRoom(Room room, Actor actor){
        TranslateTransition tT = new TranslateTransition(Duration.millis(400), actor);
        tT.setByX(room.getContactPoint().getX() - 20);
        tT.setByY(room.getContactPoint().getY() - 20);
        tT.setDelay(Duration.millis(200));
        tT.setInterpolator(Interpolator.EASE_BOTH);

        System.out.println("Room: "+room.getRoom().getId());
        tT.setOnFinished(e ->{
            Point2D actorCoordinate = room.getRoom().parentToLocal(actor.localToParent(new Point2D(actor.getLayoutX(), actor.getLayoutY())));
            room.getRoom().getChildren().add(actor);
            actor.setLayoutX(actorCoordinate.getX());
            actor.setLayoutY(actorCoordinate.getY());
        });

        animationPlanner.getChildren().add(tT);
        //account for lecturers enterer their offices & students attending lecturers in the appropriate rooms
    }
//
    public void openDoor(Room room){
        animationPlanner.getChildren().add(openDoorAnim(room.getDoor().getDoor(), room.getDoor().getDoorConfig().getRotateAngle(),
                room.getDoor().getDoorConfig().getTranslateVariable()));
    }
//
    private Animation openDoorAnim(Rectangle door, double angle, int translateVar){
        TranslateTransition tT = new TranslateTransition(Duration.millis(600), door);
        if(door.getId().matches("floorPlanDoor"))
            tT.setByY(translateVar);
        else
            tT.setByX(translateVar);

        RotateTransition rT = new RotateTransition(Duration.millis(600), door);
        rT.setByAngle(angle);
        ParallelTransition pT = new ParallelTransition(tT, rT);
        pT.setDelay(Duration.millis(200));
        pT.setInterpolator(Interpolator.EASE_BOTH);

        return pT;
    }

    public void closeDoor(Room room){
        animationPlanner.getChildren().add(closeDoorAnim(room.getDoor().getDoor(), room.getDoor().getDoorConfig().getRotateAngle(),
                room.getDoor().getDoorConfig().getTranslateVariable()));
    }

    private Animation closeDoorAnim(Rectangle door, double angle, int translateVar){
        TranslateTransition tT = new TranslateTransition(Duration.millis(600), door);
        if(door.getId().matches("floorPlanDoor"))
            tT.setByY(-translateVar);
        else
            tT.setByX(-translateVar);

        RotateTransition rT = new RotateTransition(Duration.millis(600), door);
        rT.setByAngle(-angle);
        ParallelTransition pT = new ParallelTransition(tT, rT);
        pT.setDelay(Duration.millis(200));
        pT.setInterpolator(Interpolator.EASE_BOTH);

        return pT;
    }
//
//    //incomplete
    public void enterOfficeChair(SimObject chair){
        TranslateTransition pChair = new TranslateTransition(Duration.millis(500), chair.getSimObject());
        pChair.setInterpolator(Interpolator.EASE_OUT);
        pChair.setByX(-15);
        animationPlanner.getChildren().add(pChair);

        TranslateTransition pChair1 = new TranslateTransition(Duration.millis(500), chair.getSimObject());
        pChair1.setInterpolator(Interpolator.EASE_OUT);
        pChair1.setByX(15);
        pChair1.setDelay(Duration.millis(500));
        animationPlanner.getChildren().add(pChair1);
    }

    public void toggleLight_View(Path light, Boolean turnOn){
        FadeTransition fT = new FadeTransition(Duration.millis(350), light);
        fT.setToValue((turnOn == true ? 1 : 0));
        fT.setDelay(Duration.millis(200));
        animationPlanner.getChildren().add(fT);
    }

    public void trackSimMotion(Actor sim, Path cameraView, Pane office){

        Circle tracker = new Circle(8.5);
        tracker.getStyleClass().add("tracker");
        office.getChildren().add(tracker);

        while(cameraView.contains(sim.getLayoutX(), sim.getLayoutY())){
            tracker.setCenterX(sim.getCenterX());
            tracker.setCenterY(sim.getCenterY());
        }
        
        BooleanProperty simInView = new SimpleBooleanProperty(cameraView.contains(sim.getLayoutX(), sim.getLayoutY()));
        simInView.addListener(e ->{
            new Thread(() -> {
                try {
                    while(simInView.get()) {
                        Platform.runLater(() -> {
                            tracker.setCenterX(sim.getCenterX());
                            tracker.setCenterY(sim.getCenterY());
                        });
                        Thread.sleep(200);
                    }
                }
                catch (InterruptedException ex) {}
            }).start();
        });
    }
    
    //incomplete
    //always show notification
    public static void showNotification(String message, Label notifier){
        notifier.setText(message);
        notifier.setVisible(true);
        FadeTransition fT = new FadeTransition(Duration.millis(500), notifier);
        fT.setInterpolator(Interpolator.EASE_OUT);
        fT.setToValue(1);
        animationPlanner.getChildren().add(fT);
        
        FadeTransition fT1 = new FadeTransition(Duration.millis(500), notifier);
        fT1.setInterpolator(Interpolator.EASE_OUT);
        fT1.setToValue(0);
        fT1.setDelay(Duration.seconds(1));
        fT1.setOnFinished((ActionEvent e) -> notifier.setVisible(false));
        animationPlanner.getChildren().add(fT1);
    }
    
}
